import path from 'node:path';
import { fileURLToPath } from 'node:url';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/postcss';
import { defineConfig } from 'vite';

const directory = path.dirname(fileURLToPath(import.meta.url));
const isGitHubPages = process.env.GITHUB_PAGES === '1';

export default defineConfig({
  root: directory,
  base: isGitHubPages ? './' : '/',
  publicDir: path.resolve(directory, '../public'),
  plugins: [react()],
  css: { postcss: { plugins: [tailwindcss()] } },
  resolve: { alias: { '@': path.resolve(directory, '..') } },
  build: {
    outDir: path.resolve(directory, isGitHubPages ? '../docs' : 'dist'),
    emptyOutDir: true,
  },
});
