'use client';

import { ChangeEvent, DragEvent, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowDownToLine,
  Check,
  ChevronRight,
  Crop,
  FileImage,
  ImagePlus,
  LockKeyhole,
  RefreshCw,
  Trash2,
  X,
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { NativeSelect, NativeSelectOption } from '@/components/ui/native-select';

type ResizeMode = 'original' | 'pixels' | 'ratio';
type OutputFormat = 'image/jpeg' | 'image/webp' | 'image/png';

declare global {
  interface Document {
    modelContext?: {
      registerTool: (tool: {
        name: string;
        title: string;
        description: string;
        inputSchema: object;
        annotations: { readOnlyHint: boolean; untrustedContentHint: boolean };
        execute: (input: unknown) => unknown;
      }, options?: { signal?: AbortSignal }) => void | Promise<void>;
    };
  }
}

type ImageItem = {
  id: string;
  file: File;
  sourceUrl: string;
  sourceWidth: number;
  sourceHeight: number;
  focusX: number;
  focusY: number;
  outputUrl?: string;
  outputBlob?: Blob;
  outputWidth?: number;
  outputHeight?: number;
  status: 'ready' | 'processing' | 'done' | 'error';
  error?: string;
};

const ratioPresets = [
  { label: '1 : 1', w: 1, h: 1 },
  { label: '4 : 3', w: 4, h: 3 },
  { label: '3 : 2', w: 3, h: 2 },
  { label: '16 : 9', w: 16, h: 9 },
  { label: '9 : 16', w: 9, h: 16 },
];

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

function extensionFor(format: OutputFormat) {
  return format === 'image/jpeg' ? 'jpg' : format === 'image/webp' ? 'webp' : 'png';
}

function loadImage(url: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('图片读取失败'));
    image.src = url;
  });
}

function canvasToBlob(canvas: HTMLCanvasElement, format: OutputFormat, quality: number) {
  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error('图片导出失败'))),
      format,
      format === 'image/png' ? undefined : quality,
    );
  });
}

function drawToCanvas(image: HTMLImageElement, width: number, height: number, focusX: number, focusY: number) {
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(width));
  canvas.height = Math.max(1, Math.round(height));
  const context = canvas.getContext('2d', { alpha: true });
  if (!context) throw new Error('浏览器不支持图片处理');

  context.imageSmoothingEnabled = true;
  context.imageSmoothingQuality = 'high';
  const sourceRatio = image.naturalWidth / image.naturalHeight;
  const targetRatio = canvas.width / canvas.height;
  let sourceX = 0;
  let sourceY = 0;
  let sourceWidth = image.naturalWidth;
  let sourceHeight = image.naturalHeight;
  if (targetRatio > sourceRatio) {
    sourceHeight = image.naturalWidth / targetRatio;
    sourceY = (image.naturalHeight - sourceHeight) * focusY;
  } else if (targetRatio < sourceRatio) {
    sourceWidth = image.naturalHeight * targetRatio;
    sourceX = (image.naturalWidth - sourceWidth) * focusX;
  }
  context.clearRect(0, 0, canvas.width, canvas.height);
  context.drawImage(image, sourceX, sourceY, sourceWidth, sourceHeight, 0, 0, canvas.width, canvas.height);
  return canvas;
}

async function encodeToTarget(
  image: HTMLImageElement,
  width: number,
  height: number,
  focusX: number,
  focusY: number,
  format: OutputFormat,
  quality: number,
  targetBytes: number | null,
) {
  let outputWidth = width;
  let outputHeight = height;
  let blob: Blob | null = null;
  const qualityFloor = format === 'image/webp' ? 0.72 : 0.7;

  for (let resizeAttempt = 0; resizeAttempt < 10; resizeAttempt += 1) {
    const canvas = drawToCanvas(image, outputWidth, outputHeight, focusX, focusY);
    if (!targetBytes || format === 'image/png') {
      blob = await canvasToBlob(canvas, format, quality);
      break;
    }

    const highestQuality = await canvasToBlob(canvas, format, quality);
    if (highestQuality.size <= targetBytes) {
      blob = highestQuality;
      break;
    }

    const floorQuality = await canvasToBlob(canvas, format, qualityFloor);
    if (floorQuality.size > targetBytes) {
      blob = floorQuality;
      const scale = Math.max(0.58, Math.min(0.9, Math.sqrt(targetBytes / floorQuality.size) * 0.97));
      outputWidth = Math.max(1, Math.round(outputWidth * scale));
      outputHeight = Math.max(1, Math.round(outputHeight * scale));
      continue;
    }

    let low = qualityFloor;
    let high = quality;
    let best = floorQuality;
    for (let attempt = 0; attempt < 9; attempt += 1) {
      const mid = (low + high) / 2;
      const candidate = await canvasToBlob(canvas, format, mid);
      if (candidate.size <= targetBytes) {
        best = candidate;
        low = mid;
      } else {
        high = mid;
      }
    }
    blob = best;
    break;
  }

  if (!blob) throw new Error('压缩失败');
  return { blob, width: Math.round(outputWidth), height: Math.round(outputHeight) };
}

function CropSelector({
  item,
  target,
  enabled,
  onChange,
}: {
  item: ImageItem;
  target: { width: number; height: number };
  enabled: boolean;
  onChange: (focusX: number, focusY: number) => void;
}) {
  const dragging = useRef(false);
  const sourceRatio = item.sourceWidth / item.sourceHeight;
  const targetRatio = target.width / target.height;
  const selectionWidth = targetRatio < sourceRatio ? targetRatio / sourceRatio : 1;
  const selectionHeight = targetRatio > sourceRatio ? sourceRatio / targetRatio : 1;

  function move(clientX: number, clientY: number, element: HTMLDivElement) {
    if (!enabled) return;
    const bounds = element.getBoundingClientRect();
    const pointerX = Math.max(0, Math.min(1, (clientX - bounds.left) / bounds.width));
    const pointerY = Math.max(0, Math.min(1, (clientY - bounds.top) / bounds.height));
    const nextX = selectionWidth === 1 ? 0.5 : Math.max(0, Math.min(1, (pointerX - selectionWidth / 2) / (1 - selectionWidth)));
    const nextY = selectionHeight === 1 ? 0.5 : Math.max(0, Math.min(1, (pointerY - selectionHeight / 2) / (1 - selectionHeight)));
    onChange(nextX, nextY);
  }

  return (
    <div
      className={`relative w-full touch-none overflow-hidden rounded-xl bg-muted ${enabled ? 'cursor-grab active:cursor-grabbing' : ''}`}
      style={{ aspectRatio: `${item.sourceWidth} / ${item.sourceHeight}` }}
      onPointerDown={(event) => {
        dragging.current = true;
        event.currentTarget.setPointerCapture(event.pointerId);
        move(event.clientX, event.clientY, event.currentTarget);
      }}
      onPointerMove={(event) => {
        if (dragging.current) move(event.clientX, event.clientY, event.currentTarget);
      }}
      onPointerUp={() => { dragging.current = false; }}
      onPointerCancel={() => { dragging.current = false; }}
    >
      {/* Local object URLs are required for client-side image previews. */}
      {/* oxlint-disable-next-line next/no-img-element */}
      <img src={item.sourceUrl} alt="" draggable={false} className="absolute inset-0 h-full w-full select-none object-cover" />
      {enabled && (selectionWidth < 0.999 || selectionHeight < 0.999) && (
        <div
          className="absolute grid place-items-center border-2 border-white shadow-[0_0_0_999px_rgba(49,25,40,.52)]"
          style={{
            width: `${selectionWidth * 100}%`,
            height: `${selectionHeight * 100}%`,
            left: `${(1 - selectionWidth) * item.focusX * 100}%`,
            top: `${(1 - selectionHeight) * item.focusY * 100}%`,
          }}
        >
          <Crop className="size-4 text-white drop-shadow" />
          <span className="absolute -bottom-6 whitespace-nowrap rounded-full bg-foreground/85 px-2 py-0.5 text-[9px] text-background">拖动选区</span>
        </div>
      )}
      {enabled && selectionWidth >= 0.999 && selectionHeight >= 0.999 && <div className="absolute inset-0 border-2 border-white/80" />}
    </div>
  );
}

export default function Home() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [items, setItems] = useState<ImageItem[]>([]);
  const [dragging, setDragging] = useState(false);
  const [resizeMode, setResizeMode] = useState<ResizeMode>('original');
  const [width, setWidth] = useState(1920);
  const [height, setHeight] = useState(1080);
  const [ratio, setRatio] = useState('16:9');
  const [longEdge, setLongEdge] = useState(1920);
  const [format, setFormat] = useState<OutputFormat>('image/jpeg');
  const [targetKb, setTargetKb] = useState(0);
  const [processing, setProcessing] = useState(false);

  const completed = items.filter((item) => item.status === 'done').length;
  const sourceTotal = useMemo(() => items.reduce((sum, item) => sum + item.file.size, 0), [items]);
  const outputTotal = useMemo(() => items.reduce((sum, item) => sum + (item.outputBlob?.size ?? 0), 0), [items]);

  useEffect(() => {
    if (!document.modelContext?.registerTool) return;
    const lifecycle = new AbortController();
    const register = document.modelContext.registerTool({
      name: 'configure_image_compression',
      title: '设置图片压缩参数',
      description: '在瓜瓜图压页面中设置输出像素、格式和可选的目标文件大小。',
      inputSchema: {
        type: 'object',
        properties: {
          width: { type: 'integer', minimum: 1, maximum: 12000 },
          height: { type: 'integer', minimum: 1, maximum: 12000 },
          format: { type: 'string', enum: ['webp', 'jpeg', 'png'] },
          targetKb: { type: 'integer', minimum: 0, maximum: 100000 },
        },
        required: ['width', 'height'],
        additionalProperties: false,
      },
      annotations: { readOnlyHint: false, untrustedContentHint: false },
      execute(input) {
        const value = input as { width?: number; height?: number; format?: string; targetKb?: number };
        if (!Number.isInteger(value.width) || !Number.isInteger(value.height) || value.width! < 1 || value.height! < 1 || value.width! > 12000 || value.height! > 12000) {
          throw new Error('宽度和高度必须是 1-12000 之间的整数');
        }
        const formatMap: Record<string, OutputFormat> = { webp: 'image/webp', jpeg: 'image/jpeg', png: 'image/png' };
        if (value.format !== undefined && !formatMap[value.format]) throw new Error('格式必须是 webp、jpeg 或 png');
        setResizeMode('pixels');
        setWidth(value.width!);
        setHeight(value.height!);
        if (value.format) setFormat(formatMap[value.format]);
        if (value.targetKb !== undefined) setTargetKb(value.targetKb);
        return { configured: true, width: value.width, height: value.height, format: value.format ?? 'jpeg', targetKb: value.targetKb ?? 0 };
      },
    }, { signal: lifecycle.signal });
    void Promise.resolve(register).catch(() => undefined);
    return () => lifecycle.abort();
  }, []);

  async function addFiles(files: FileList | File[]) {
    const accepted = Array.from(files).filter((file) => file.type.startsWith('image/'));
    const loaded: (ImageItem | null)[] = await Promise.all(accepted.map(async (file) => {
      const sourceUrl = URL.createObjectURL(file);
      try {
        const image = await loadImage(sourceUrl);
        return {
          id: `${file.name}-${file.lastModified}-${crypto.randomUUID()}`,
          file,
          sourceUrl,
          sourceWidth: image.naturalWidth,
          sourceHeight: image.naturalHeight,
          focusX: 0.5,
          focusY: 0.5,
          status: 'ready' as const,
        };
      } catch {
        URL.revokeObjectURL(sourceUrl);
        return null;
      }
    }));
    setItems((current) => [...current, ...loaded.filter((item): item is ImageItem => item !== null)]);
  }

  function handleInput(event: ChangeEvent<HTMLInputElement>) {
    if (event.target.files) void addFiles(event.target.files);
    event.target.value = '';
  }

  function handleDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
    setDragging(false);
    void addFiles(event.dataTransfer.files);
  }

  function removeItem(id: string) {
    setItems((current) => {
      const target = current.find((item) => item.id === id);
      if (target) {
        URL.revokeObjectURL(target.sourceUrl);
        if (target.outputUrl) URL.revokeObjectURL(target.outputUrl);
      }
      return current.filter((item) => item.id !== id);
    });
  }

  function clearAll() {
    items.forEach((item) => {
      URL.revokeObjectURL(item.sourceUrl);
      if (item.outputUrl) URL.revokeObjectURL(item.outputUrl);
    });
    setItems([]);
  }

  function dimensionsFor(item: ImageItem) {
    if (resizeMode === 'original') return { width: item.sourceWidth, height: item.sourceHeight };
    if (resizeMode === 'pixels') return { width: Math.max(1, width), height: Math.max(1, height) };
    const [ratioWidth, ratioHeight] = ratio.split(':').map(Number);
    if (ratioWidth >= ratioHeight) {
      const nextWidth = Math.min(longEdge, item.sourceWidth);
      return { width: nextWidth, height: Math.max(1, Math.round(nextWidth * ratioHeight / ratioWidth)) };
    }
    const nextHeight = Math.min(longEdge, item.sourceHeight);
    return { width: Math.max(1, Math.round(nextHeight * ratioWidth / ratioHeight)), height: nextHeight };
  }

  async function compressAll() {
    if (!items.length || processing) return;
    setProcessing(true);
    setItems((current) => current.map((item) => ({ ...item, status: 'processing', error: undefined })));
    for (const item of items) {
      try {
        const image = await loadImage(item.sourceUrl);
        const dimensions = dimensionsFor(item);
        const result = await encodeToTarget(
          image,
          dimensions.width,
          dimensions.height,
          item.focusX,
          item.focusY,
          format,
          0.92,
          targetKb > 0 && format !== 'image/png' ? targetKb * 1024 : null,
        );
        const outputUrl = URL.createObjectURL(result.blob);
        setItems((current) => current.map((currentItem) => {
          if (currentItem.id !== item.id) return currentItem;
          if (currentItem.outputUrl) URL.revokeObjectURL(currentItem.outputUrl);
          return { ...currentItem, outputUrl, outputBlob: result.blob, outputWidth: result.width, outputHeight: result.height, status: 'done' };
        }));
      } catch (error) {
        setItems((current) => current.map((currentItem) => currentItem.id === item.id
          ? { ...currentItem, status: 'error', error: error instanceof Error ? error.message : '压缩失败' }
          : currentItem));
      }
    }
    setProcessing(false);
  }

  function download(item: ImageItem) {
    if (!item.outputUrl) return;
    const anchor = document.createElement('a');
    const basename = item.file.name.replace(/\.[^.]+$/, '');
    anchor.href = item.outputUrl;
    anchor.download = `${basename}-瓜瓜图压.${extensionFor(format)}`;
    anchor.click();
  }

  function downloadAll() {
    items.filter((item) => item.status === 'done').forEach((item, index) => {
      window.setTimeout(() => download(item), index * 180);
    });
  }

  return (
    <main className="min-h-[100dvh] bg-background text-foreground">
      <header className="border-b border-border bg-background/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1480px] items-center justify-between px-5 py-4 lg:px-8">
          <div className="flex items-center gap-3">
            <div className="size-11 overflow-hidden rounded-xl border border-border bg-card">
              {/* oxlint-disable-next-line next/no-img-element */}
              <img src="./logo.jpg" alt="瓜瓜图压标志" className="h-full w-full object-cover" />
            </div>
            <div className="font-heading text-lg font-bold tracking-[-0.035em]">瓜瓜图压</div>
          </div>
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <LockKeyhole className="size-4 text-primary" />
            <span className="hidden sm:inline">图片仅在本地处理</span>
            <Button size="icon" className="ml-1 rounded-xl" aria-label="添加图片" onClick={() => inputRef.current?.click()}><ImagePlus /></Button>
          </div>
        </div>
      </header>

      <section className="mx-auto grid max-w-[1480px] gap-10 px-5 py-8 lg:grid-cols-[320px_minmax(0,1fr)] lg:gap-14 lg:px-8 lg:py-12 xl:grid-cols-[350px_minmax(0,1fr)]">
        <aside className="lg:sticky lg:top-8 lg:h-fit">
          <p className="mb-5 text-xs font-medium tracking-[0.16em] text-muted-foreground">IMAGE COMPRESSOR</p>
          <h1 className="font-heading text-[2.65rem] font-bold leading-[1.08] tracking-[-0.055em] sm:text-5xl">轻一点，<br />清晰依然。</h1>
          <p className="mt-5 max-w-[19rem] text-base leading-7 text-muted-foreground">批量压缩图片，准确调整像素、比例与文件大小。无需上传服务器。</p>

          <div className="mt-12 border-t border-border pt-5 text-sm text-muted-foreground">
            <div className="flex items-center gap-3"><Check className="size-5 text-primary" /><span>原图不会离开设备</span></div>
            <div className="mt-3 flex items-center gap-3"><FileImage className="size-5 text-primary" /><span>支持一次处理多张</span></div>
          </div>

          <div className="mt-12 border-t border-border pt-5">
            <p className="text-xs font-medium text-muted-foreground">敬请期待</p>
            <h2 className="mt-2 font-heading text-lg font-bold tracking-[-0.025em]">更多图片工具正在准备</h2>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">GIF、PDF 与批量命名功能将陆续加入。</p>
          </div>
        </aside>

        <section className="min-w-0 overflow-hidden rounded-2xl border border-border bg-card shadow-[0_24px_70px_rgba(40,40,36,.10)]">
          <div
            onDragEnter={(event) => { event.preventDefault(); setDragging(true); }}
            onDragOver={(event) => event.preventDefault()}
            onDragLeave={() => setDragging(false)}
            onDrop={handleDrop}
            className={`group m-4 grid min-h-[270px] place-items-center rounded-xl border border-dashed px-6 py-10 text-center transition-colors ${dragging ? 'border-foreground bg-muted' : 'border-border bg-muted/55 hover:border-foreground/45'}`}
          >
            <div>
              <Button size="icon" className="mb-5 size-14 rounded-xl" aria-label="选择图片" onClick={() => inputRef.current?.click()}><ImagePlus className="size-6" /></Button>
              <h2 className="font-heading text-lg font-bold">拖入图片，或点击选择</h2>
              <p className="mt-2 text-sm text-muted-foreground">支持 JPG、PNG、WebP，可一次选择多张</p>
              <Button variant="outline" size="lg" className="mt-5 rounded-xl bg-card" onClick={() => inputRef.current?.click()}>浏览文件</Button>
              <input ref={inputRef} type="file" accept="image/*" multiple className="hidden" onChange={handleInput} />
            </div>
          </div>

          <section className="border-t border-border p-4 sm:p-5">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <div><h2 className="font-heading font-bold">输出设置</h2><p className="mt-1 text-xs text-muted-foreground">默认保留原图尺寸，默认输出 JPG</p></div>
              {items.length > 0 && <Button variant="ghost" onClick={clearAll} className="text-muted-foreground"><Trash2 />清空列表</Button>}
            </div>

            <div className="grid gap-4 xl:grid-cols-[1.35fr_1fr_1fr_auto] xl:items-end">
              <div>
                <p className="mb-2 text-xs font-medium text-muted-foreground">输出规格</p>
                <div className="grid grid-cols-3 rounded-lg bg-muted p-1">
                  {([['original', '保留原图'], ['pixels', '像素尺寸'], ['ratio', '画面比例']] as const).map(([value, label]) => (
                    <button key={value} type="button" aria-pressed={resizeMode === value} onClick={() => setResizeMode(value)} className={`rounded-md px-2 py-2.5 text-xs font-semibold transition active:scale-[.98] ${resizeMode === value ? 'bg-foreground text-background shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>{label}</button>
                  ))}
                </div>
              </div>

              {resizeMode === 'original' ? (
                <div className="rounded-lg border border-border bg-background px-3 py-3 text-sm text-muted-foreground">保持原尺寸与原比例</div>
              ) : resizeMode === 'pixels' ? (
                <div className="grid grid-cols-[1fr_auto_1fr] items-end gap-2">
                  <label htmlFor="width-input" className="space-y-2 text-xs font-medium text-muted-foreground">宽度<Input id="width-input" min={1} max={12000} type="number" value={width} onChange={(event) => setWidth(Number(event.target.value))} className="h-10 bg-background font-semibold text-foreground" /></label>
                  <X className="mb-3 size-3.5 text-muted-foreground" />
                  <label htmlFor="height-input" className="space-y-2 text-xs font-medium text-muted-foreground">高度<Input id="height-input" min={1} max={12000} type="number" value={height} onChange={(event) => setHeight(Number(event.target.value))} className="h-10 bg-background font-semibold text-foreground" /></label>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="grid grid-cols-5 gap-1">{ratioPresets.map((preset) => { const value = `${preset.w}:${preset.h}`; return <button type="button" aria-pressed={ratio === value} key={value} onClick={() => setRatio(value)} className={`rounded-md border px-1 py-2 text-[11px] font-semibold transition active:scale-[.98] ${ratio === value ? 'border-foreground bg-foreground text-background' : 'border-border bg-background text-muted-foreground hover:text-foreground'}`}>{preset.label}</button>; })}</div>
                  <label htmlFor="long-edge-input" className="relative block"><Input id="long-edge-input" min={64} max={12000} type="number" value={longEdge} onChange={(event) => setLongEdge(Number(event.target.value))} className="h-10 bg-background pr-10 font-semibold text-foreground" /><span className="absolute right-3 top-3 text-xs text-muted-foreground">px</span></label>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2">
                <label htmlFor="format-select" className="space-y-2 text-xs font-medium text-muted-foreground">输出格式<NativeSelect id="format-select" value={format} onChange={(event) => setFormat(event.target.value as OutputFormat)} className="w-full bg-background"><NativeSelectOption value="image/jpeg">JPG 默认</NativeSelectOption><NativeSelectOption value="image/webp">WebP 更小</NativeSelectOption><NativeSelectOption value="image/png">PNG 无损</NativeSelectOption></NativeSelect></label>
                <label htmlFor="target-kb-input" className="space-y-2 text-xs font-medium text-muted-foreground">目标大小<div className="relative"><Input id="target-kb-input" disabled={format === 'image/png'} min={0} type="number" value={targetKb || ''} placeholder={format === 'image/png' ? '不支持' : '可选'} onChange={(event) => setTargetKb(Number(event.target.value))} className="h-10 bg-background pr-9 text-foreground" /><span className="absolute right-3 top-3 text-xs text-muted-foreground">KB</span></div></label>
              </div>

              <div className="flex items-center justify-between gap-3 xl:flex-col xl:items-end">
                <span className="text-xs text-muted-foreground">{items.length ? `${items.length} 张待处理` : '等待图片'}</span>
                <Button size="icon" onClick={compressAll} disabled={!items.length || processing} className="size-12 rounded-xl" aria-label={processing ? '正在压缩' : '开始压缩'}>{processing ? <RefreshCw className="animate-spin" /> : <ChevronRight />}</Button>
              </div>
            </div>
          </section>

          {items.length > 0 && (
            <section className="border-t border-border">
              <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
                <div><h2 className="font-heading font-bold">图片列表 <span className="font-normal text-muted-foreground">{items.length}</span></h2>{completed > 0 && <p className="mt-1 text-xs text-muted-foreground">完成 {completed} 张，{formatBytes(sourceTotal)} → {formatBytes(outputTotal)}</p>}</div>
                {completed > 0 && <Button variant="outline" onClick={downloadAll} className="rounded-xl"><ArrowDownToLine className="text-primary" />全部下载</Button>}
              </div>
              <div className="divide-y divide-border">{items.map((item) => (
                <article key={item.id} className="grid grid-cols-[96px_minmax(0,1fr)_auto] items-center gap-3 px-4 py-3 sm:grid-cols-[150px_minmax(0,1fr)_auto] sm:px-5">
                  <CropSelector item={item} target={dimensionsFor(item)} enabled={resizeMode !== 'original'} onChange={(focusX, focusY) => setItems((current) => current.map((currentItem) => currentItem.id === item.id ? { ...currentItem, focusX, focusY, status: currentItem.status === 'done' ? 'ready' : currentItem.status } : currentItem))} />
                  <div className="min-w-0"><p className="truncate text-sm font-semibold">{item.file.name}</p><p className="mt-1 text-xs leading-5 text-muted-foreground">{item.sourceWidth} × {item.sourceHeight}，{formatBytes(item.file.size)}{item.status === 'done' && item.outputBlob ? `  →  ${item.outputWidth} × ${item.outputHeight}，${formatBytes(item.outputBlob.size)}` : ''}</p>{item.status === 'error' && <p className="mt-1 text-xs text-destructive">{item.error}</p>}</div>
                  <div className="flex items-center gap-1">{item.status === 'processing' && <RefreshCw className="mr-1 size-4 animate-spin text-primary" />}{item.status === 'done' && <Button size="icon" className="rounded-lg" aria-label={`下载 ${item.file.name}`} onClick={() => download(item)}><ArrowDownToLine /></Button>}<Button variant="ghost" size="icon" className="rounded-lg" aria-label={`移除 ${item.file.name}`} onClick={() => removeItem(item.id)}><Trash2 /></Button></div>
                </article>
              ))}</div>
            </section>
          )}
        </section>
      </section>

      <footer className="mx-auto flex max-w-[1480px] flex-col gap-2 border-t border-border px-5 py-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between lg:px-8"><span>瓜瓜图压，浏览器本地图片工具</span><span>原图不离开设备</span></footer>
    </main>
  );
}
