import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';

const geistSans = Geist({ variable: '--font-geist-sans', subsets: ['latin'] });
const geistMono = Geist_Mono({ variable: '--font-geist-mono', subsets: ['latin'] });

export const metadata: Metadata = {
  title: '瓜瓜图压 · 在线图片压缩与尺寸调整',
  description: '在浏览器本地批量压缩图片，调整像素、画面比例与目标文件大小。',
  openGraph: {
    title: '瓜瓜图压 · 在线图片压缩与尺寸调整',
    description: '批量调整像素、比例与文件大小。无需上传，快速又安心。',
    images: [{ url: '/og.png', width: 1200, height: 630, alt: '瓜瓜图压图片压缩工具' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: '瓜瓜图压 · 在线图片压缩与尺寸调整',
    description: '批量调整像素、比例与文件大小。无需上传，快速又安心。',
    images: ['/og.png'],
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>{children}</body>
    </html>
  );
}
